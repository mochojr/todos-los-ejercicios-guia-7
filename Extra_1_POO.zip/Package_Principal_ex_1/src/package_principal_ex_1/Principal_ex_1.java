
package package_principal_ex_1;


public class Principal_ex_1 {

   
    public static void main(String[] args) {
      
        
        
    }
    
}
